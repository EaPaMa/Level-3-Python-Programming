def game():

  Colours = ['red', 'yellow', 'blue', 'green']
  Interstellar = ['yellow', 'red', 'green', 'blue', 'red']
  ComplexColours = ['green', 'green', 'blue', 'yellow',  'red', 'yellow']
  LabyrinthColours = ['blue', 'yellow', 'red', 'yellow', 'blue', 'green', 'yellow', 'red', 'blue']
  System = ['q', 'r']
  
  import RPi.GPIO as GPIO
  import time
  import random
  import sys

  
  #Raspberry Pi code for our breadboard and LED's
  GPIO.setmode(GPIO.BCM)
  GPIO.setup(26,GPIO.OUT)
  GPIO.setup(17,GPIO.OUT)
  GPIO.setup(27,GPIO.OUT)
  GPIO.setup(22,GPIO.OUT)
  

  
  AnsweredCorrectly = False
  AnsweredInterstellarCorrectly = False
  AnsweredComplexCorrectly = False
  AnsweredLabyrinthCorrectly = False
  AnsweredOmegaCorrectly = False
  UserPoint = 0
  
  print ("**************************************")
  print ("****************COSMIC****************")
  print ("********the Colour Memory Game********")
  print ("**************************************")
  print ("**************************************\n")
  

  
  
  
  #loading high scores text file
  #with open('game.txt') as file_object:
   # contents = file_object.read()
    #print(contents)

  file_object = open('game', "r")
  print(file_object.readline())
  
  
  
  print("")
  
  #player name user input
  players={}
  person=input("What is your name? ")
  print("")
  
  #UserPoint= 0
  players[person]=UserPoint
  #print (players)
  print ("Welcome,", (person), ", your current score is {0}".format (UserPoint))
    
  print ("")
  print ("Level 1: Easy Mirage\n") 
  
  print ("Pay attention to the flashing lights!\n")

  #for counter in range(4):
    #print(Colours[counter])
  #red led
  for x in range (0,1):
    time.sleep(3)
    GPIO.output(26,GPIO.HIGH)
    time.sleep(1)
    GPIO.output(26,GPIO.LOW)
    time.sleep(1)
  #yellow led
  for x in range (0,1):
    GPIO.output(17,GPIO.HIGH)
    time.sleep(1)
    GPIO.output(17,GPIO.LOW)
    time.sleep(1)
  #blue led
  for x in range (0,1):
    GPIO.output(27,GPIO.HIGH)
    time.sleep(1)
    GPIO.output(27,GPIO.LOW)
    time.sleep(1)
  #green led
  for x in range (0,1):
    GPIO.output(22,GPIO.HIGH)
    time.sleep(1)
    GPIO.output(22,GPIO.LOW)
    time.sleep(1)
    
  
  
  firstColour = ""
  secondColour = ""
  thirdColour = ""
  fourthColour = ""
  
  #code for output, plus while loop for keep asking questions til they geddit right
  while AnsweredCorrectly == False:
    print("")
    print ("Can you remember the colour sequence?\n")
    print ("Take a guess. Please input the order of sequence (or enter q to exit):\n")
   
    firstColour = input("the first colour? ")
    
    if firstColour == ("q"):
      #with open ('HallOfFame.txt', "a") as file_object:
        #file_object.write (person+' - '+str(UserPoint)+'\n')
        #print("Your name and score has been saved to the Hall of Fame!\n")
        exit()

    #prints the high scores hall of fame again, to show the new high scores
      #with open('HallOfFame.txt') as file_object:
        #contents = file_object.read()
        #print(contents)
  
    secondColour = input("the second colour? ")
    thirdColour = input("the third colour? ")
    fourthColour = input("the fourth colour? ")
    
    #code for comparing whether user input is the same 
    #as the flashing Colours
  
    if firstColour not in Colours[0]:
      print("")
      print ("first colour %s IS INCORRECT!" % (firstColour.upper()))
    else:
      print("")
      print ("first colour %s is correct!" % (firstColour))
    if secondColour not in Colours[1]:
      print ("second colour %s IS INCORRECT!" % (secondColour.upper()))
    else:
      print ("second colour %s is correct!" % (secondColour))
    if thirdColour not in Colours[2]:
      print ("third colour %s IS INCORRECT!" % (thirdColour.upper()))
    else:
      print ("third colour %s is correct!" % (thirdColour))
    if fourthColour not in Colours[3]:
      print ("fourth colour %s IS INCORRECT!" % (fourthColour.upper()))
    else:
      print ("fourth colour %s is correct!" % (fourthColour))
  
    if (firstColour in Colours[0] and secondColour in Colours[1] and thirdColour in Colours[2] and fourthColour in Colours[3]):
      AnsweredCorrectly = True
  
  if AnsweredCorrectly == True:
    UserPoint = UserPoint +1
    print("")
    print ("Congratulations,", (person), ", you earned 1 point!\n")
    print ("You now have: "+str(UserPoint)+" points!")
    print("")
  
  # Part 2 of the colour memory game
  print ("Next Level in the Colour Memory Game\n")
  print ("Level 2: Interstellar Beam\n")
  print ("")
  print ("Pay attention to the flashing lights!\n")
  #for counter in range(5):
    #print(Interstellar[counter])

  #yellow led
  for x in range (0,1):
    time.sleep(3)
    GPIO.output(17,GPIO.HIGH)
    time.sleep(1)
    GPIO.output(17,GPIO.LOW)
    time.sleep(1)
  #red led
  for x in range (0,1):
    GPIO.output(26,GPIO.HIGH)
    time.sleep(1)
    GPIO.output(26,GPIO.LOW)
    time.sleep(1)
  #green led
  for x in range (0,1):
    GPIO.output(22,GPIO.HIGH)
    time.sleep(1)
    GPIO.output(22,GPIO.LOW)
    time.sleep(1)
  #blue led
  for x in range (0,1):
    GPIO.output(27,GPIO.HIGH)
    time.sleep(1)
    GPIO.output(27,GPIO.LOW)
    time.sleep(1)
  #red led
  for x in range (0,1):
    GPIO.output(26,GPIO.HIGH)
    time.sleep(1)
    GPIO.output(26,GPIO.LOW)
    time.sleep(1)


  
  InterstellarColour1 = ""
  InterstellarColour2 = ""
  InterstellarColour3 = ""
  InterstellarColour4 = ""
  InterstellarColour5 = ""
  
  #code for output, plus while loop for keep asking questions til they geddit right
  while AnsweredInterstellarCorrectly == False:
    print("")
    print ("Can you remember the colour sequence?\n")
    print ("Take a guess. Please input the order of sequence (or enter q to exit):\n")
   
    InterstellarColour1 = input("the first colour? ")
    
    if InterstellarColour1 == ("q"):
      #with open ('HallOfFame.txt', "a") as file_object:
        #file_object.write (person+' - '+str(UserPoint)+'\n')
        #print("Your name and score has been saved to the Hall of Fame!\n")
        exit()

    #prints the high scores hall of fame again, to show the new high scores
      #with open('HallOfFame.txt') as file_object:
        #contents = file_object.read()
        #print(contents)
  
    InterstellarColour2 = input("the second colour? ")
    InterstellarColour3 = input("the third colour? ")
    InterstellarColour4 = input("the fourth colour? ")
    InterstellarColour5 = input("the fifth colour? ")
    
    #code for comparing whether user input is the same 
    #as the flashing Colours
  
    if InterstellarColour1 not in Interstellar[0]:
      print("")
      print ("first colour %s IS INCORRECT!" % (InterstellarColour1.upper()))
    else:
      print("")
      print ("first colour %s is correct!" % (InterstellarColour1))
    if InterstellarColour2 not in Interstellar[1]:
      print ("second colour %s IS INCORRECT!" % (InterstellarColour2.upper()))
    else:
      print ("second colour %s is correct!" % (InterstellarColour2))
    if InterstellarColour3 not in Interstellar[2]:
      print ("third colour %s IS INCORRECT!" % (InterstellarColour3.upper()))
    else:
      print ("third colour %s is correct!" % (InterstellarColour3))
    if InterstellarColour4 not in Interstellar[3]:
      print ("fourth colour %s IS INCORRECT!" % (InterstellarColour4.upper()))
    else:
      print ("fourth colour %s is correct!" % (InterstellarColour4))
    if InterstellarColour5 not in Interstellar[4]:
      print ("fifth colour %s IS INCORRECT!" % (InterstellarColour5.upper()))
    else:
      print ("fifth colour %s is correct!" % (InterstellarColour5))
  
    if (InterstellarColour1 in Interstellar[0] and InterstellarColour2 in Interstellar[1] and InterstellarColour3 in Interstellar[2] and InterstellarColour4 in Interstellar[3] and InterstellarColour5 in Interstellar[4]):
      AnsweredInterstellarCorrectly = True
  
  if AnsweredInterstellarCorrectly == True:
    UserPoint = UserPoint +1
    print("")
    print ("Congratulations,", (person), ", you earned 1 point!\n")
    print ("You now have: "+str(UserPoint)+" point!")
    print("")
  
  
  
  #part 3 of the colour memory game
  print ("Next Level in the Colour Memory Game\n")
  print ("Level 3: Complex Aurora\n")
  print("")
  print ("Pay attention to the flashing lights!\n")
  #for counter in range(6):
    #print(ComplexColours[counter])


  #green led
  for x in range (0,1):
    time.sleep(3)
    GPIO.output(22,GPIO.HIGH)
    time.sleep(1)
    GPIO.output(22,GPIO.LOW)
    time.sleep(1)
  #green led
  for x in range (0,1):
    GPIO.output(22,GPIO.HIGH)
    time.sleep(1)
    GPIO.output(22,GPIO.LOW)
    time.sleep(1)
  #blue led
  for x in range (0,1):
    GPIO.output(27,GPIO.HIGH)
    time.sleep(1)
    GPIO.output(27,GPIO.LOW)
    time.sleep(1)
  #yellow led
  for x in range (0,1):
    GPIO.output(17,GPIO.HIGH)
    time.sleep(1)
    GPIO.output(17,GPIO.LOW)
    time.sleep(1)
  #red led
  for x in range (0,1):
    GPIO.output(26,GPIO.HIGH)
    time.sleep(1)
    GPIO.output(26,GPIO.LOW)
    time.sleep(1)
  #yellow led
  for x in range (0,1):
    GPIO.output(17,GPIO.HIGH)
    time.sleep(1)
    GPIO.output(17,GPIO.LOW)
    time.sleep(1)
  
  
  ComplexColour1 = ""
  ComplexColour2 = ""
  ComplexColour3 = ""
  ComplexColour4 = ""
  ComplexColour5 = ""
  ComplexColour6 = ""
  
  
  #code for output, plus while loop for keep asking questions til they geddit right
  while AnsweredComplexCorrectly == False:
    print("")
    print ("Can you remember the colour sequence?\n")
    print ("Take a guess. Please input the order of sequence (or enter q to exit):\n")
    ComplexColour1 = input("the first colour? ")
  
    if ComplexColour1 == ("q"):
      #with open ('HallOfFame.txt', "a") as file_object:
        #file_object.write (person+' - '+str(UserPoint)+'\n')
        #print("Your name and score has been saved to the Hall of Fame!\n")
        exit()

    #prints the high scores hall of fame again, to show the new high scores
      #with open('HallOfFame.txt') as file_object:
        #contents = file_object.read()
        #print(contents)
      
    ComplexColour2 = input("the second colour? ")
    ComplexColour3 = input("the third colour? ")
    ComplexColour4 = input("the fourth colour? ")
    ComplexColour5 = input("the fifth colour? ")
    ComplexColour6 = input("the sixth colour? ")
  
  
    #code for comparing whether user input is the same 
    #as the flashing Colours
    if ComplexColour1 not in ComplexColours[0]:
      print("")
      print ("first colour %s IS INCORRECT!" % (ComplexColour1.upper()))
    else:
      print("")
      print ("first colour %s is correct!" % (ComplexColour1))
    if ComplexColour2 not in ComplexColours[1]:
      print ("second colour %s IS INCORRECT!" % (ComplexColour2.upper()))
    else:
      print ("second colour %s is correct!" % (ComplexColour2))
    if ComplexColour3 not in ComplexColours[2]:
      print ("third colour %s IS INCORRECT!" % (ComplexColour3.upper()))
    else:
      print ("third colour %s is correct!" % (ComplexColour3))
    if ComplexColour4 not in ComplexColours[3]:
      print ("fourth colour %s IS INCORRECT!" % (ComplexColour4.upper()))
    else:
      print ("fourth colour %s is correct!" % (ComplexColour4))
    if ComplexColour5 not in ComplexColours[4]:
      print ("fifth colour %s IS INCORRECT!" % (ComplexColour5.upper()))
    else: 
      print ("fifth colour %s is correct!" % (ComplexColour5))
    if ComplexColour6 not in ComplexColours[5]:
      print ("sixth colour %s IS INCORRECT!\n" % (ComplexColour6.upper()))
    else:
      print ("sixth colour %s is correct!\n" % (ComplexColour6))
    
      
    if (ComplexColour1 in ComplexColours[0] and ComplexColour2 in ComplexColours[1] and ComplexColour3 in ComplexColours[2] and ComplexColour4 in ComplexColours[3]) and ComplexColour5 in ComplexColours[4] and ComplexColour6 in ComplexColours[5]:
      AnsweredComplexCorrectly = True
  
  if AnsweredComplexCorrectly == True:
    UserPoint = UserPoint +1
    print("")
    print ("Congratulations," + (person) + ", you earned 1 point!\n")
    print ("You now have:"+str(UserPoint)+" points!")
    print ("")
  #third level of memory game
  print ("Next level in the Colour Memory Game\n")
  print ("Level 4: Glistening Labyrinth")
  print("")
  print ("Pay attention to the flashing lights!\n")
  #for counter in range(9):
   # print(LabyrinthineColours[counter])


  #blue led
  for x in range (0,1):
    time.sleep(3)
    GPIO.output(27,GPIO.HIGH)
    time.sleep(1)
    GPIO.output(27,GPIO.LOW)
    time.sleep(1)
  #yellow led
  for x in range (0,1):
    GPIO.output(17,GPIO.HIGH)
    time.sleep(1)
    GPIO.output(17,GPIO.LOW)
    time.sleep(1)
  #red led
  for x in range (0,1):
    GPIO.output(26,GPIO.HIGH)
    time.sleep(1)
    GPIO.output(26,GPIO.LOW)
    time.sleep(1)
  #yellow led
  for x in range (0,1):
    GPIO.output(17,GPIO.HIGH)
    time.sleep(1)
    GPIO.output(17,GPIO.LOW)
    time.sleep(1)
  #blue led
  for x in range (0,1):
    GPIO.output(27,GPIO.HIGH)
    time.sleep(1)
    GPIO.output(27,GPIO.LOW)
    time.sleep(1)
  #green led
  for x in range (0,1):
    GPIO.output(22,GPIO.HIGH)
    time.sleep(1)
    GPIO.output(22,GPIO.LOW)
    time.sleep(1)
  #yellow led
  for x in range (0,1):
    GPIO.output(17,GPIO.HIGH)
    time.sleep(1)
    GPIO.output(17,GPIO.LOW)
    time.sleep(1)
  #red led
  for x in range (0,1):
    GPIO.output(26,GPIO.HIGH)
    time.sleep(1)
    GPIO.output(26,GPIO.LOW)
    time.sleep(1)
  #blue led
  for x in range (0,1):
    GPIO.output(27,GPIO.HIGH)
    time.sleep(1)
    GPIO.output(27,GPIO.LOW)
    time.sleep(1)
    
  
  LabyrinthColour1 = ""
  LabyrinthColour2 = ""
  LabyrinthColour3 = ""
  LabyrinthColour4 = ""
  LabyrinthColour5 = ""
  LabyrinthColour6 = ""
  LabyrinthColour7 = ""
  LabyrinthColour8 = ""
  LabyrinthColour9 = ""
  
  #code for output, plus while loop for keep asking questions til they geddit right
  while AnsweredLabyrinthCorrectly == False:
    print("")
    print ("Can you remember the colour sequence?\n")
    print ("Take a guess. Please input the order of sequence (or enter q to exit):\n")
    LabyrinthColour1 = input("the first colour? ")
    LabyrinthColour2 = input("the second colour? ")
    LabyrinthColour3 = input("the third colour? ")
    LabyrinthColour4 = input("the fourth colour? ")
    LabyrinthColour5 = input("the fifth colour? ")
    LabyrinthColour6 = input("the sixth colour? ")
    LabyrinthColour7 = input("the seventh colour? ")
    LabyrinthColour8 = input("the eighth colour? ")
    LabyrinthColour9 = input("the ninth colour? ")
  
  
    #code for exiting the program if user enters q
    if LabyrinthColour1 == ("q"):
      #with open ('HallOfFame.txt', "a") as file_object:
        #file_object.write (person+' - '+str(UserPoint)+'\n')
        #print("Your name and score has been saved to the Hall of Fame!\n")
        exit()

    #prints the high scores hall of fame again, to show the new high scores
    #with open('HallOfFame.txt') as file_object:
      #contents = file_object.read()
      #print(contents)
      
  
  
     #code for comparing whether user input is the same 
    #as the flashing Colours
    if LabyrinthColour1 not in LabyrinthColours[0]:
      print("")
      print ("first colour %s IS INCORRECT!" % (LabyrinthColour1.upper()))
    else:
      print("")
      print ("first colour %s is correct!" % (LabyrinthColour1))
    if LabyrinthColour2 not in LabyrinthColours[1]:
      print ("second colour %s IS INCORRECT!" % (LabyrinthColour2.upper()))
    else:
      print ("second colour %s is correct!" % (LabyrinthColour2))
    if LabyrinthColour3 not in LabyrinthColours[2]:
      print ("third colour %s IS INCORRECT!" % (LabyrinthColour3.upper()))
    else:
      print ("third colour %s is correct!" % (LabyrinthColour3))
    if LabyrinthColour4 not in LabyrinthColours[3]:
      print ("fourth colour %s IS INCORRECT!" % (LabyrinthColour4.upper()))
    else:
      print ("fourth colour %s is correct!" % (LabyrinthColour4))
    if LabyrinthColour5 not in LabyrinthColours[4]:
      print ("fifth colour %s IS INCORRECT!" % (LabyrinthColour5.upper()))
    else: 
      print ("fifth colour %s is correct!" % (LabyrinthColour5))
    if LabyrinthColour6 not in LabyrinthColours[5]:
      print ("sixth colour %s IS INCORRECT!\n" % (LabyrinthColour6.upper()))
    else:
      print ("sixth colour %s is correct!" % (LabyrinthColour6))
    if LabyrinthColour7 not in LabyrinthColours[6]:
      print ("seventh colour %s IS INCORRECT!" % (LabyrinthColour7.upper()))
    else:
      print ("seventh colour %s is correct!" % (LabyrinthColour7))
    if LabyrinthColour8 not in LabyrinthColours[7]:
      print ("eighth colour %s IS INCORRECT!" % (LabyrinthColour8.upper()))
    else:
      print ("eighth colour %s is correct!" % (LabyrinthColour8))
    if LabyrinthColour9 not in LabyrinthColours[8]:
      print ("ninth colour %s IS INCORRECT!\n" % (LabyrinthColour9.upper()))
    else:
      print ("ninth colour %s is correct!\n" % (LabyrinthColour9))
    
    
      
    if (LabyrinthColour1 in LabyrinthColours[0] and LabyrinthColour2 in LabyrinthColours[1] and LabyrinthColour3 in LabyrinthColours[2] and LabyrinthColour4 in LabyrinthColours[3]) and LabyrinthColour5 in LabyrinthColours[4] and LabyrinthColour6 in LabyrinthColours[5] and LabyrinthColour7 in LabyrinthColours[6] and LabyrinthColour8 in LabyrinthColours[7] and LabyrinthColour9 in LabyrinthColours[8]:
      AnsweredLabyrinthCorrectly = True
  
  if AnsweredLabyrinthCorrectly == True:
    UserPoint = UserPoint +1
    print ("")
    print ("Congratulations,", (person), ", you earned 1 point!\n")
    print ("You now have:"+str(UserPoint)+" points!")
    print ("")
  
  
  
  
    
  #fourth level of memory game
  print ("Next level in the Colour Memory Game\n")
  print ("Level 5: Random Omega")
  print("")
  print ("Pay attention to the flashing lights!\n")
  
  #code that randomises the Labyrinth list
  print("")
  random.shuffle(LabyrinthColours)
  print ("Glistening Labyrinth Colour list reshuffled: ", LabyrinthColours)




  
  #start of Omega level game
  while AnsweredOmegaCorrectly == False:
    print("")
    print ("Can you remember the colour sequence?\n")
    print ("Take a guess. Please input the order of sequence (or enter q to exit):\n")
    LabyrinthColour1 = input("the first colour? ")
    LabyrinthColour2 = input("the second colour? ")
    LabyrinthColour3 = input("the third colour? ")
    LabyrinthColour4 = input("the fourth colour? ")
    LabyrinthColour5 = input("the fifth colour? ")
    LabyrinthColour6 = input("the sixth colour? ")
    LabyrinthColour7 = input("the seventh colour? ")
    LabyrinthColour8 = input("the eighth colour? ")
    LabyrinthColour9 = input("the ninth colour? ")
  
  #code for exiting the program if user enters q
    if LabyrinthColour1 == ("q"):
      #with open ('HallOfFame.txt', "a") as file_object:
        #file_object.write (person+' - '+str(UserPoint)+'\n')
       # print("Your name and score has been saved to the Hall of Fame!\n")
        exit()

  #prints the high scores hall of fame again, to show the new high scores
    #with open('HallOfFame.txt') as file_object:
     # contents = file_object.read()
     # print(contents)
  
  
  
    if LabyrinthColour1 not in LabyrinthColours[0]:
      print("")
      print ("first colour %s IS INCORRECT!" % (LabyrinthColour1.upper()))
    else:
      print("")
      print ("first colour %s is correct!" % (LabyrinthColour1))
    if LabyrinthColour2 not in LabyrinthColours[1]:
      print ("second colour %s IS INCORRECT!" % (LabyrinthColour2.upper()))
    else:
      print ("second colour %s is correct!" % (LabyrinthColour2))
    if LabyrinthColour3 not in LabyrinthColours[2]:
      print ("third colour %s IS INCORRECT!" % (LabyrinthColour3.upper()))
    else:
      print ("third colour %s is correct!" % (LabyrinthColour3))
    if LabyrinthColour4 not in LabyrinthColours[3]:
      print ("fourth colour %s IS INCORRECT!" % (LabyrinthColour4.upper()))
    else:
      print ("fourth colour %s is correct!" % (LabyrinthColour4))
    if LabyrinthColour5 not in LabyrinthColours[4]:
      print ("fifth colour %s IS INCORRECT!" % (LabyrinthColour5.upper()))
    else: 
      print ("fifth colour %s is correct!" % (LabyrinthColour5))
    if LabyrinthColour6 not in LabyrinthColours[5]:
      print ("sixth colour %s IS INCORRECT!\n" % (LabyrinthColour6.upper()))
    else:
      print ("sixth colour %s is correct!" % (LabyrinthColour6))
    if LabyrinthColour7 not in LabyrinthColours[6]:
      print ("seventh colour %s IS INCORRECT!" % (LabyrinthColour7.upper()))
    else:
      print ("seventh colour %s is correct!" % (LabyrinthColour7))
    if LabyrinthColour8 not in LabyrinthColours[7]:
      print ("eighth colour %s IS INCORRECT!" % (LabyrinthColour8.upper()))
    else:
      print ("eighth colour %s is correct!" % (LabyrinthColour8))
    if LabyrinthColour9 not in LabyrinthColours[8]:
      print ("ninth colour %s IS INCORRECT!\n" % (LabyrinthColour9.upper()))
    else:
      print ("ninth colour %s is correct!\n" % (LabyrinthColour9))
    
    
      
    if (LabyrinthColour1 in LabyrinthColours[0] and LabyrinthColour2 in LabyrinthColours[1] and LabyrinthColour3 in LabyrinthColours[2] and LabyrinthColour4 in LabyrinthColours[3]) and LabyrinthColour5 in LabyrinthColours[4] and LabyrinthColour6 in LabyrinthColours[5] and LabyrinthColour7 in LabyrinthColours[6] and LabyrinthColour8 in LabyrinthColours[7] and LabyrinthColour9 in LabyrinthColours[8]:
      AnsweredOmegaCorrectly = True
  
  if AnsweredOmegaCorrectly == True:
    UserPoint = UserPoint +1
    print ("")
    print ("Congratulations," +(person) + "you earned 1 point!\n")
    print ("You now have:"+str(UserPoint)+" points!")
    print ("")
    
  #saving score to .txt file 
  with open ('game.txt', "a") as file_object:
    file_object.write (person+' - '+str(UserPoint)+'\n')
    print("Your name and score has been saved to the Hall of Fame!\n")
    
  #prints the high scores hall of fame again, to show the new high scores
  with open('game.txt') as file_object:
    contents = file_object.read()
    print(contents)
  
  
  print ("Congratulations, you have finished the Cosmic colour memory game!!")
  userInput = input("If you wish to have another go enter 'R' to restart or 'Q' to quit").capitalize()

  if userInput == "R":
    game()

  elif userInput == "Q":
    exit()


game()
